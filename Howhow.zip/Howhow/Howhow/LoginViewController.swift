//
//  LoginViewController.swift
//  Howhow
//
//  Created by Jiang Bing on 10/7/18.
//  Copyright © 2018 Page semi-protected Apple Inc. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var userInputEmailTextField: UITextField!
    @IBOutlet weak var userInputPasswordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var goToPostButton: UIButton!
    @IBOutlet weak var ChangePasswordButton: UIButton!
    
    
    
    @IBAction func LoginButtonClicked(_ sender: UIButton) {
        
        let userInputEmail = userInputEmailTextField.text
        let userInputPassword = userInputPasswordTextField.text
        
        /// 1、获得沙盒的根路径
        let home = NSHomeDirectory() as NSString;
        /// 2、获得Documents路径，使用NSString对象的stringByAppendingPathComponent()方法拼接路径
        let docPath = home.appendingPathComponent("Documents") as NSString;
        /// 3、获取文本文件路径
        let filePath = docPath.appendingPathComponent("User.plist");
        let dataSource = NSArray(contentsOfFile: filePath);
        //print(dataSource)
       
        if (userInputEmailTextField.text?.contains("@"))!{
            if(dataSource != nil){
                
                let systemEmail = dataSource![1] as! String
                let systemPassword = dataSource![2] as! String
                if userInputEmail == systemEmail && userInputPassword == systemPassword{
                    //进入主页面
                    print("Main Pageeeee")
                    let alertController = UIAlertController(title: "Login successfully!", message: nil, preferredStyle: .alert)
                    //显示提示框
                    self.present(alertController, animated: true, completion: nil)
                    //0.5秒钟后自动消失
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
                        self.presentedViewController?.dismiss(animated: false, completion: nil)
                    }
                    goToPostButton.isHidden = false
                    loginButton.isHidden = true
                    ChangePasswordButton.isHidden = false
                    
                    
                }
                else{
                    let alert = UIAlertController(title: "Error", message: "Email or password may be incorrect", preferredStyle: UIAlertController.Style.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                    alert.addAction(ok)
                    self.present(alert, animated: true, completion: nil )
                }
            }
            else{
                let alert = UIAlertController(title: "Error", message: "Email or password may be incorrect", preferredStyle: UIAlertController.Style.alert)
                let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                alert.addAction(ok)
                self.present(alert, animated: true, completion: nil )
                
            }
        }
        else{
            let alert = UIAlertController(title: "Error", message: "Please confirm email", preferredStyle: UIAlertController.Style.alert)
            let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            alert.addAction(ok)
            present(alert, animated: true, completion: nil )
            userInputEmailTextField.text = ""
            userInputPasswordTextField.text = ""
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        userInputEmailTextField.text = ""
        userInputPasswordTextField.text = ""
        goToPostButton.isHidden = true
        loginButton.isHidden = false
        ChangePasswordButton.isHidden = true
        
        
    }

}
