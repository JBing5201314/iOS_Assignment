import UIKit

class RegistrationViewController: UIViewController{
    
    @IBOutlet weak var usernameInputTextField: UITextField!
    @IBOutlet weak var emailInputTextField: UITextField!
    @IBOutlet weak var passwordInputTextField: UITextField!
    @IBOutlet weak var confirmInputTextField: UITextField!
    @IBOutlet weak var loginSrgmentedControl: UISegmentedControl!
    @IBOutlet weak var registrationButton: UIButton!
    @IBOutlet weak var goToPostButton: UIButton!


    @IBAction func registrationButtonClicked(_ sender: UIButton) {
        if usernameInputTextField.text?.isEmpty == true || emailInputTextField.text?.isEmpty == true ||  passwordInputTextField.text?.isEmpty == true || confirmInputTextField.text?.isEmpty == true{
            
            let alert = UIAlertController(title: "Error", message: "Please complete information", preferredStyle: UIAlertController.Style.alert)
            let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            alert.addAction(ok)
            present(alert, animated: true, completion: nil )
            
        }

        else{
            if (emailInputTextField.text?.contains("@"))!{
                if passwordInputTextField.text != confirmInputTextField.text{
                    let alert = UIAlertController(title: "Error", message: "Please confirm password", preferredStyle: UIAlertController.Style.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                    alert.addAction(ok)
                    present(alert, animated: true, completion: nil )
                }
                else{
                    let home = NSHomeDirectory() as NSString;
                    /// 2、获得Documents路径，使用NSString对象的stringByAppendingPathComponent()方法拼接路径
                    let docPath = home.appendingPathComponent("Documents") as NSString;
                    /// 3、获取文本文件路径
                    let filePath = docPath.appendingPathComponent("User.plist");
                    let dataSource = NSMutableArray();
                    dataSource.add(usernameInputTextField.text!)
                    dataSource.add(emailInputTextField.text!)
                    dataSource.add(passwordInputTextField.text!)
                    dataSource.write(toFile: filePath, atomically: true)
                    
                    
                    let alertController = UIAlertController(title: "Registered successfully!", message: nil, preferredStyle: .alert)
                    //显示提示框
                    self.present(alertController, animated: true, completion: nil)
                    //0.5秒钟后自动消失
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
                        self.presentedViewController?.dismiss(animated: false, completion: nil)
                    }
                    registrationButton.isHidden = true
                    goToPostButton.isHidden = false
                    
                    }
                
            }else{
                
                let alert = UIAlertController(title: "Error", message: "Please confirm email", preferredStyle: UIAlertController.Style.alert)
                let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                alert.addAction(ok)
                present(alert, animated: true, completion: nil )
                emailInputTextField.text = ""
            }
            
        }
        
    }

    

    override func viewDidLoad() {
        super.viewDidLoad()
        usernameInputTextField.text = ""
        emailInputTextField.text = ""
        passwordInputTextField.text = ""
        confirmInputTextField.text = ""
        registrationButton.isHidden = false
        goToPostButton.isHidden = true
        
        }
        
        
        
        
        

    
    


}
