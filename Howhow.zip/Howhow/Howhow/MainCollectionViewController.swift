//
//  MainCollectionViewController.swift
//  Howhow
//
//  Created by Jiang Bing on 10/5/18.
//  Copyright © 2018 Page semi-protected Apple Inc. All rights reserved.
//

import UIKit


private let reuseIdentifier = "Cell"
class MainCollectionViewController: UICollectionViewController, CreatePostViewControllerDelegate{
    
    

    @IBOutlet weak var MainFlowLayout: UICollectionViewFlowLayout!
    
    var posts: [PostData] = [PostData(avatarImage: UIImage(named: "avatarImage01.jpg")!, username: "Miranda", time: "2018-10-01 19:40:16 +0000", photo: UIImage(named: "photo01.jpg")!, content: "orem ipsum dolor sit amet, consectetuer adipisI elit desco.orem ipsum dolor sit amet, consectetuer adipisI elit desco.Lorem ipsum dolor sit amet, consectetuer adipisI elit desco. Lorem ipsum dolor sit amet, consectetuer adipisI elit desco."), PostData(avatarImage: UIImage(named: "avatarImage02.jpg")!, username: "Jack", time: "2018-10-02 19:40:16 +0000", photo: UIImage(named: "photo02.jpg")!, content: "Lorem ipsum dolor sit amet, consectetuer adipisI elit desco.orem ipsum dolor sit amet, consectetuer adipisI elit desco.orem ipsum dolor sit amet, consectetuer adipisI elit desco.orem ipsum dolor sit amet, consectetuer adipisI elit desco.orem ipsum dolor sit amet, consectetuer adipisI elit desco.orem ipsum dolor sit amet, consectetuer adipisI elit desco."), PostData(avatarImage: UIImage(named: "avatarImage01.jpg")!, username: "Miranda", time: "2018-10-03 19:40:16 +0000", photo: UIImage(named: "photo01.jpg")!, content: "Lorem ipsum dolor sit amet, consectetuer adipisI elit desco. Lorem ipsum dolor sit amet, consectetuer adipisI elit desco.orem ipsum dolor sit amet, consectetuer adipisI elit desco.orem ipsum dolor sit amet, consectetuer adipisI elit desco."), PostData(avatarImage: UIImage(named: "avatarImage02.jpg")!, username: "Jack", time: "2018-10-04 19:40:16 +0000", photo: UIImage(named: "photo02.jpg")!, content: "Lorem ipsum dolor sit amet, consectetuer adipisI elit desco."), PostData(avatarImage: UIImage(named: "avatarImage01.jpg")!, username: "Miranda", time: "2018-10-05 19:40:16 +0000", photo: UIImage(named: "photo01.jpg")!, content: "Lorem ipsum dolor sit amet, consectetuer adipisI elit desco. Lorem ipsum dolor sit amet, consectetuer adipisI elit desco."), PostData(avatarImage: UIImage(named: "avatarImage02.jpg")!, username: "Jack", time: "2018-10-06 19:40:16 +0000", photo: UIImage(named: "photo02.jpg")!, content: "Lorem ipsum dolor sit amet, consectetuer adipisI elit desco.")]

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        MainFlowLayout.estimatedItemSize = MainFlowLayout.itemSize
        
    }


    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "to create post segue"{
            let vc = segue.destination as? CreatePostViewController
            vc?.delegate = self
        }
    }
    


    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return posts.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! MainCollectionViewCell
        let post = posts[indexPath.row]
        cell.avatarImageView.image = post.avatarImage
        cell.usernameLabel.text = post.username
        cell.timeLabel.text = post.time
        cell.photoImageView.image = post.photo
        cell.postContentLabel.text = post.content
        return cell
    }

    func createPostViewController(didFinishCreate post: PostData) {
        posts.insert(post, at: 0)
        collectionView?.reloadData()
    }
    
}

