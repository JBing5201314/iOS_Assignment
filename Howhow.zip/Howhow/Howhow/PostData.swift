//
//  PostData.swift
//  Howhow
//
//  Created by Jiang Bing on 10/6/18.
//  Copyright © 2018 Page semi-protected Apple Inc. All rights reserved.
//

import UIKit

struct PostData {
    let avatarImage: UIImage
    let username: String
    let time: String
    let photo: UIImage
    let content: String
}
