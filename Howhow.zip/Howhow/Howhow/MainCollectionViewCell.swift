//
//  MainCollectionViewCell.swift
//  Howhow
//
//  Created by Jiang Bing on 10/5/18.
//  Copyright © 2018 Page semi-protected Apple Inc. All rights reserved.
//

import UIKit

class MainCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var postContentLabel: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        //configration
        avatarImageView.layer.cornerRadius = avatarImageView.bounds.width / 2
        avatarImageView.clipsToBounds = true
        photoImageView.clipsToBounds = true
        
        
        
        
    }
    
}
