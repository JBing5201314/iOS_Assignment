import UIKit
import Photos
protocol CreatePostViewControllerDelegate{
    func createPostViewController(didFinishCreate post : PostData)
}


class CreatePostViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[.originalImage] as? UIImage
        photoImageView.image = image
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
        
    }
    
    @IBOutlet weak var contentTextView: UITextView!
    @IBOutlet weak var photoImageView: UIImageView!
    
    var delegate: CreatePostViewControllerDelegate?
    
    @IBAction func cancelButtonClicked(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func doneButtonClicked(_ sender: UIBarButtonItem) {
        let avatarImage = UIImage(named: "avatarImage01.jpg")!
        
        /// 1、获得沙盒的根路径
        let home = NSHomeDirectory() as NSString;
        /// 2、获得Documents路径，使用NSString对象的stringByAppendingPathComponent()方法拼接路径
        let docPath = home.appendingPathComponent("Documents") as NSString;
        /// 3、获取文本文件路径
        let filePath = docPath.appendingPathComponent("User.plist");
        let dataSource = NSArray(contentsOfFile: filePath);
        
        let username = dataSource![0] as! String
        let date = Date()
        let time = String(describing: date)
        print(date)
        guard let photo = photoImageView.image else{
            alert(body: "Need Photo!")
            return
            
        }
        guard let content = contentTextView.text, !content.isEmpty else{
            alert(body: "Need Contect!")
            return
        }
        let postData = PostData(avatarImage: avatarImage, username: username, time: time, photo:photo, content: content)
        //print(postData)
        delegate?.createPostViewController(didFinishCreate : postData)
        self.navigationController?.popViewController(animated: true)
       // dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func openCameraButton(_ sender: UIButton) {
        openPhotoLibrary()
    }

    func needPermission(){
        if PHPhotoLibrary.authorizationStatus() == .notDetermined{
            PHPhotoLibrary.requestAuthorization( { (status) in
                self.openPhotoLibrary()
            })
        }else{
            //user dont give permission
            let url = URL(string: UIApplication.openSettingsURLString)!
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    func openPhotoLibrary(){
        //check permission
        if PHPhotoLibrary.authorizationStatus() == .authorized{
            //open photo library
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            self.present(imagePicker, animated: true, completion: nil)
            
        }else{
            //need permission
            needPermission()
        }
    

    }
    

    func alert(body: String){
        let alert = UIAlertController(title: "Error", message: body, preferredStyle: UIAlertController.Style.alert)
        let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(ok)
        present(alert, animated: true, completion: nil )
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        contentTextView.text = ""
    }
}
