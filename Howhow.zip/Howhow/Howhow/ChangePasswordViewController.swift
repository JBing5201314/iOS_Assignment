import UIKit

class ChangePasswordViewController: UIViewController {

    @IBOutlet weak var oldtTextField: UITextField!
    @IBOutlet weak var newTextField: UITextField!
    @IBOutlet weak var confirmTextField: UITextField!
    
    
    @IBAction func okButtonClicked(_ sender: UIButton) {
        
        let old = oldtTextField.text
        let new = newTextField.text
        let confirm = confirmTextField.text
        
        /// 1、获得沙盒的根路径
        let home = NSHomeDirectory() as NSString;
        /// 2、获得Documents路径，使用NSString对象的stringByAppendingPathComponent()方法拼接路径
        let docPath = home.appendingPathComponent("Documents") as NSString;
        /// 3、获取文本文件路径
        let filePath = docPath.appendingPathComponent("User.plist");
        let dataSource = NSArray(contentsOfFile: filePath);
        //print(dataSource)
        let username = dataSource![0]
        let email = dataSource![1]
        
        if old?.isEmpty == false || new?.isEmpty == false || confirm?.isEmpty == false {
            if new == confirm{
                if old != new{
                    
                    let home = NSHomeDirectory() as NSString;
                    /// 2、获得Documents路径，使用NSString对象的stringByAppendingPathComponent()方法拼接路径
                    let docPath = home.appendingPathComponent("Documents") as NSString;
                    /// 3、获取文本文件路径
                    let filePath = docPath.appendingPathComponent("User.plist");
                    let dataSource = NSMutableArray();
                    dataSource.add(username)
                    dataSource.add(email)
                    dataSource.add(new!)
                    dataSource.write(toFile: filePath, atomically: true)
                    
                    
                    let alertController = UIAlertController(title: "Change Password Successfully!", message: nil, preferredStyle: .alert)
                    //显示提示框
                    self.present(alertController, animated: true, completion: nil)
                    //0.5秒钟后自动消失
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
                        self.presentedViewController?.dismiss(animated: false, completion: nil)
                        self.oldtTextField.text = ""
                        self.newTextField.text = ""
                        self.confirmTextField.text = ""
                    }
 
                    
                }else{
                    let alert = UIAlertController(title: "Error", message: "The new password cannot be the same as the old password", preferredStyle: UIAlertController.Style.alert)
                    let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                    alert.addAction(ok)
                    present(alert, animated: true, completion: nil )
                }
            }
            
            else{
                let alert = UIAlertController(title: "Error", message: "Please confirm password", preferredStyle: UIAlertController.Style.alert)
                let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                alert.addAction(ok)
                present(alert, animated: true, completion: nil )
            }
    }
        else{
            let alert = UIAlertController(title: "Error", message: "Please complete information", preferredStyle: UIAlertController.Style.alert)
            let ok = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            alert.addAction(ok)
            present(alert, animated: true, completion: nil )
        }
        
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    

  
}
