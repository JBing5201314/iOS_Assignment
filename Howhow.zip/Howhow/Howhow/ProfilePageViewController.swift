import UIKit

class ProfilePageViewController: UIViewController {

    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var userEmailLabel: UILabel!
    
    @IBOutlet weak var postCountLabel: UILabel!

    @IBOutlet weak var followerCountLabel: UILabel!
    @IBOutlet weak var followingCountLabel: UILabel!
    

    @IBOutlet weak var notificationLabel: UILabel!
    @IBOutlet weak var notificationSwitch: UISwitch!
    
    @IBAction func notificationSwitchValueChanges(_ sender: UISwitch) {
        if sender == notificationSwitch{
            let ud = UserDefaults.standard
            ud.set(notificationSwitch.isOn, forKey: "notification key")
            ud.synchronize()
            if notificationSwitch.isOn{
              notificationLabel.text = "on"
            }else{
                notificationLabel.text = "off"
            }
        }
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        avatarImageView.layer.cornerRadius = avatarImageView.bounds.width / 2
        avatarImageView.clipsToBounds = true
        
        
        /// 1、获得沙盒的根路径
        let home = NSHomeDirectory() as NSString;
        /// 2、获得Documents路径，使用NSString对象的stringByAppendingPathComponent()方法拼接路径
        let docPath = home.appendingPathComponent("Documents") as NSString;
        /// 3、获取文本文件路径
        let filePath = docPath.appendingPathComponent("User.plist");
        let dataSource = NSArray(contentsOfFile: filePath);
        
        
        avatarImageView.image = UIImage(named: "avatarImage01.jpg")
        usernameLabel.text = dataSource![0] as? String
        userEmailLabel.text = dataSource![1] as? String
        postCountLabel.text = "88"
        followerCountLabel.text = "123"
        followingCountLabel.text = "321"
        

        let ud = UserDefaults.standard
        let isOn = ud.bool(forKey: "notification key")
        notificationSwitch.isOn = isOn
        if notificationSwitch.isOn{
            notificationLabel.text = "on"
        }else{
            notificationLabel.text = "off"
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
