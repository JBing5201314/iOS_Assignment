//
//  RemoveAccountViewController.swift
//  Howhow
//
//  Created by Jiang Bing on 10/8/18.
//  Copyright © 2018 Page semi-protected Apple Inc. All rights reserved.
//

import UIKit

class RemoveAccountViewController: UIViewController {

    @IBOutlet weak var yesButton: UIButton!
    @IBOutlet weak var noButton: UIButton!
    @IBOutlet weak var goButton: UIButton!
    
    
    
    @IBAction func yesButtonClickes(_ sender: UIButton) {
        
        let home = NSHomeDirectory() as NSString;
        /// 2、获得Documents路径，使用NSString对象的stringByAppendingPathComponent()方法拼接路径
        let docPath = home.appendingPathComponent("Documents") as NSString;
        /// 3、获取文本文件路径
        let filePath = docPath.appendingPathComponent("User.plist");
        let dataSource = NSMutableArray();
        dataSource.add("")
        dataSource.add("")
        dataSource.add("")
        dataSource.write(toFile: filePath, atomically: true)
        
        let alertController = UIAlertController(title: "Remove Account Successfully!", message: nil, preferredStyle: .alert)
        //显示提示框
        self.present(alertController, animated: true, completion: nil)
        //0.5秒钟后自动消失
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.presentedViewController?.dismiss(animated: false, completion: nil)
            self.yesButton.isHidden = true
            self.noButton.isHidden = true
            self.goButton.isHidden = false
        }
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        yesButton.isHidden = false
        noButton.isHidden = false
        goButton.isHidden = true
        
    }
    


}
